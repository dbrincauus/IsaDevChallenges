# Governify Project Bluejay Infrastructure
Infrastructure for deploying the ecosystem as described in the BLUEJAY project.

